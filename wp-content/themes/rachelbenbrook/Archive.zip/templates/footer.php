<footer class="content-info navbar-fixed-bottom" role="contentinfo">
  <div class="text-right">
    &copy; <?php echo date('Y'); ?> Rachel Benbrook
  </div>
</footer>
